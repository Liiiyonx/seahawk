import { createRouter, createWebHistory } from 'vue-router'
import { isLoggedIn } from '@/utils/auth'

const routes = [
  { path: '/', redirect: '/login' },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/LoginView.vue'),
    meta: { title: '登录', noLayout: true },
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: () => import('@/views/DashboardView.vue'),
    meta: { title: '监测大屏', icon: '◈' },
  },
  {
    path: '/events',
    name: 'events',
    component: () => import('@/views/EventsView.vue'),
    meta: { title: '事件中心', icon: '◉' },
  },
  {
    path: '/tasks',
    name: 'tasks',
    component: () => import('@/views/TasksView.vue'),
    meta: { title: '工单看板', icon: '▤' },
  },
  {
    path: '/devices',
    name: 'devices',
    component: () => import('@/views/DevicesView.vue'),
    meta: { title: '设备态势', icon: '◎' },
  },
  {
    path: '/reports',
    name: 'reports',
    component: () => import('@/views/ReportsView.vue'),
    meta: { title: '治理报表', icon: '▦' },
  },
  {
    path: '/agents',
    name: 'agents',
    component: () => import('@/views/AgentsView.vue'),
    meta: { title: '智能体', icon: '◉' },
    // 支持 query 参数直达：?run=<run_id> 自动展开运行详情/回放，?page=<n> 直达指定页
    props: (route) => ({
      runId: typeof route.query.run === 'string' ? route.query.run : '',
      page: Number(route.query.page) > 0 ? Number(route.query.page) : 1,
    }),
  },
  {
    path: '/knowledge',
    name: 'knowledge',
    component: () => import('@/views/KnowledgeView.vue'),
    meta: { title: '知识智能体', icon: '◇' },
  },
  {
    path: '/analyze',
    name: 'analyze',
    component: () => import('@/views/AnalyzeView.vue'),
    meta: { title: '图片分析', icon: '◎' },
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

// ---------- 路由守卫：未登录一律回登录页 ----------
router.beforeEach((to) => {
  const isLoginPage = to.name === 'login'
  if (!isLoginPage && !isLoggedIn()) {
    return { name: 'login', query: { redirect: to.fullPath } }
  }
  return true
})

router.afterEach((to) => {
  const title = to.meta?.title
  document.title = title ? `${title} · 探海灵眸 SeaSight` : '探海灵眸 SeaSight'
})

export default router
export { routes }
