<template>
  <div class="map-panel panel">
    <div class="panel-title">
      <span>垃圾分布热力与设备态势</span>
      <div class="map-legend">
        <span v-for="c in legend" :key="c.key" class="map-legend__item">
          <i class="dot" :style="{ background: c.color }"></i>{{ c.label }}
        </span>
      </div>
    </div>
    <div class="map-panel__body">
      <div id="seasight-map" ref="mapEl"></div>

      <!-- 无地图密钥/离线时的内置态势图 -->
      <svg
        v-if="mapMode === 'offline'"
        class="offline-map"
        :class="{ 'offline-map--dragging': dragging }"
        viewBox="0 0 1000 700"
        role="img"
        aria-label="连江县海区态势图"
        @pointerdown="startOfflineDrag"
        @pointermove="moveOfflineDrag"
        @pointerup="endOfflineDrag"
        @pointercancel="endOfflineDrag"
        @pointerleave="endOfflineDrag"
      >
        <defs>
          <linearGradient id="offline-water" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#e5f0f8" />
            <stop offset="0.55" stop-color="#dceaf5" />
            <stop offset="1" stop-color="#d3e3f0" />
          </linearGradient>
          <linearGradient id="offline-land" x1="0" y1="0" x2="0.85" y2="1">
            <stop offset="0" stop-color="#fbfcf9" />
            <stop offset="1" stop-color="#f1f3ef" />
          </linearGradient>
          <pattern id="offline-water-texture" width="210" height="132" patternUnits="userSpaceOnUse">
            <path
              d="M-30 94C22 94 42 55 91 55s67 39 119 39 70-45 124-45"
              fill="none"
              stroke="#ffffff"
              stroke-opacity="0.23"
              stroke-width="1.2"
            />
            <path
              d="M-44 128C8 128 28 89 77 89s67 39 119 39 70-45 124-45"
              fill="none"
              stroke="#9fc5dd"
              stroke-opacity="0.13"
              stroke-width="1"
            />
          </pattern>
          <clipPath id="offline-land-clip">
            <path :d="lianjiangOutline" />
          </clipPath>
          <filter id="offline-shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="5" stdDeviation="6" flood-color="#526b7d" flood-opacity="0.17" />
          </filter>
        </defs>

        <rect width="1000" height="700" fill="url(#offline-water)" />
        <rect width="1000" height="700" fill="url(#offline-water-texture)" />

        <g :transform="offlineTransform">
          <path class="offline-map__land-shadow" :d="lianjiangOutline" />
          <path class="offline-map__land" :d="lianjiangOutline" />

          <g class="offline-map__terrain" clip-path="url(#offline-land-clip)">
            <path d="M-20 112C120 58 258 84 374 146S650 252 1018 172" />
            <path d="M-34 196C116 142 250 170 370 228S664 332 1028 246" />
            <path d="M-18 292C130 238 268 268 392 322S702 410 1026 326" />
            <path d="M10 382C156 332 290 356 418 410S730 488 1010 420" />
            <path d="M126 522C270 476 388 500 510 545S790 616 986 568" />
          </g>

          <g class="offline-map__roads" clip-path="url(#offline-land-clip)">
            <g class="offline-map__road-casing">
              <path d="M118 473C218 430 322 388 448 332S705 258 884 188" />
              <path d="M224 476C284 410 306 337 364 270S470 158 572 132" />
              <path d="M154 391C282 366 362 344 486 302S716 232 866 211" />
              <path d="M291 354C382 326 452 291 522 252S656 183 776 160" />
            </g>
            <g class="offline-map__road-fill">
              <path d="M118 473C218 430 322 388 448 332S705 258 884 188" />
              <path d="M224 476C284 410 306 337 364 270S470 158 572 132" />
              <path d="M154 391C282 366 362 344 486 302S716 232 866 211" />
              <path d="M291 354C382 326 452 291 522 252S656 183 776 160" />
            </g>
            <g class="offline-map__road-minor">
              <path d="M180 420C250 402 318 365 381 320S492 244 612 213" />
              <path d="M253 446C323 414 388 372 452 324S568 229 690 201" />
              <path d="M336 292C393 255 452 217 514 181S630 139 718 132" />
              <path d="M393 373C458 349 517 313 574 270S684 214 789 204" />
              <path d="M287 228C354 233 423 253 493 292S637 348 787 340" />
              <path d="M96 337C178 331 253 316 322 289S437 232 506 202" />
            </g>
          </g>

          <path class="offline-map__coast" :d="lianjiangOutline" />

          <g class="offline-map__labels" aria-hidden="true">
            <g class="offline-map__place offline-map__place--major" transform="translate(236 462)">
              <circle r="3.4" />
              <text x="8" y="4">连江</text>
            </g>
            <g class="offline-map__place" transform="translate(514 297)">
              <circle r="2.5" />
              <text x="7" y="3.5">黄岐</text>
            </g>
            <g class="offline-map__place" transform="translate(563 158)">
              <circle r="2.5" />
              <text x="7" y="3.5">苔菉</text>
            </g>
            <g class="offline-map__place" transform="translate(454 327)">
              <circle r="2.5" />
              <text x="7" y="3.5">筱埕</text>
            </g>
            <g class="offline-map__place" transform="translate(323 416)">
              <circle r="2.5" />
              <text x="7" y="3.5">晓澳</text>
            </g>
            <g class="offline-map__place" transform="translate(309 351)">
              <circle r="2.5" />
              <text x="7" y="3.5">浦口</text>
            </g>
            <g class="offline-map__place" transform="translate(456 221)">
              <circle r="2.5" />
              <text x="7" y="3.5">安凯</text>
            </g>
            <text class="offline-map__water-label" x="661" y="432">黄岐湾</text>
            <text class="offline-map__ocean-label" x="858" y="596">东 海</text>
          </g>

          <g v-if="layerEnabled('heat')" class="offline-map__heat">
            <circle
              v-for="cell in localHeat"
              :key="cell.key"
              :cx="cell.x"
              :cy="cell.y"
              :r="cell.radius"
              :fill="cell.color"
              :fill-opacity="cell.opacity"
            />
          </g>

          <g v-if="layerEnabled('cameras')">
            <g
              v-for="marker in localCameras"
              :key="marker.id"
              class="offline-map__marker"
              role="button"
              tabindex="0"
              :aria-label="marker.title"
              @click.stop="selectOfflineMarker(marker)"
              @keydown.enter.stop="selectOfflineMarker(marker)"
            >
              <circle :cx="marker.x" :cy="marker.y" r="10" :fill="marker.color" opacity="0.2" />
              <circle :cx="marker.x" :cy="marker.y" r="5.4" :fill="marker.color" />
              <path
                :d="cameraPinPath(marker)"
                :fill="marker.color"
                stroke="#ffffff"
                stroke-width="1.5"
              />
            </g>
          </g>

          <g v-if="layerEnabled('robots')">
            <g
              v-for="marker in localRobots"
              :key="marker.id"
              class="offline-map__marker"
              role="button"
              tabindex="0"
              :aria-label="marker.title"
              @click.stop="selectOfflineMarker(marker)"
              @keydown.enter.stop="selectOfflineMarker(marker)"
            >
              <circle :cx="marker.x" :cy="marker.y" r="12" :fill="marker.color" opacity="0.18" />
              <path
                :d="boatPath(marker)"
                :fill="marker.color"
                stroke="#ffffff"
                stroke-width="1.6"
                stroke-linejoin="round"
              />
            </g>
          </g>

          <g v-if="layerEnabled('events')">
            <g
              v-for="marker in localEvents"
              :key="marker.id"
              class="offline-map__marker"
              role="button"
              tabindex="0"
              :aria-label="marker.title"
              @click.stop="selectOfflineMarker(marker)"
              @keydown.enter.stop="selectOfflineMarker(marker)"
            >
              <circle :cx="marker.x" :cy="marker.y" r="7.5" :fill="marker.color" opacity="0.18" />
              <circle
                :cx="marker.x"
                :cy="marker.y"
                r="4"
                :fill="marker.color"
                stroke="#ffffff"
                stroke-width="1.5"
              />
            </g>
          </g>
        </g>
      </svg>

      <!-- 图层开关 -->
      <div v-if="mapMode !== 'loading'" class="map-tools">
        <label v-for="layer in layers" :key="layer.key" class="map-tools__item">
          <input type="checkbox" v-model="layer.on" @change="refresh" />
          <span>{{ layer.label }}</span>
        </label>
      </div>

      <div v-if="mapMode === 'offline'" class="map-controls" aria-label="地图缩放控制">
        <button type="button" title="放大" aria-label="放大地图" @click="changeOfflineZoom(0.2)">+</button>
        <button type="button" title="缩小" aria-label="缩小地图" @click="changeOfflineZoom(-0.2)">−</button>
        <button type="button" title="复位" aria-label="复位地图" @click="resetOfflineView">⊙</button>
      </div>

      <div v-if="mapMode === 'offline'" class="offline-badge" :title="offlineReason">
        <span>连江县 · 本地海区态势图</span>
        <small>简约矢量底图</small>
      </div>

      <div v-if="selectedMarker" class="offline-info" role="dialog" aria-label="点位详情">
        <button type="button" aria-label="关闭点位详情" @click="selectedMarker = null">×</button>
        <strong>{{ selectedMarker.title }}</strong>
        <span v-for="row in selectedMarker.rows" :key="row.label">
          {{ row.label }}：{{ row.value }}
        </span>
      </div>

      <div v-if="mapMode === 'loading'" class="map-loading">
        <span class="map-loading__spinner" aria-hidden="true"></span>
        <span>地图加载中</span>
      </div>

      <!-- 极端异常兜底 -->
      <div v-if="loadError" class="map-error">
        <p>地图加载失败</p>
        <p class="map-error__hint">{{ loadError }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
/**
 * 地图组件（腾讯地图 GL JS）。
 *
 * ★ 合规说明
 *   地图服务只允许使用腾讯地图 / 高德 / 百度 / 天地图。
 *   本项目用腾讯地图，且采用官方的 key 代理模式：
 *   - SDK 从官方 CDN 加载，URL 上**不带 key 参数**
 *   - SDK 内部请求自动走本地代理，密钥由后端持有
 *   - 前端不出现任何密钥，避免被反编译窃取
 *
 * 注意：_TMapSecurityConfig 必须在 SDK script 标签之前设置。
 * 两者同时用会白屏，所以这里不能在组件内再调 setConfig。
 */
import { ref, computed, onMounted, onUnmounted, watch, reactive } from 'vue'
import { classColor, classLabel, CLASS_ORDER } from '@/utils/constants'
import lianjiangGeo from '@/assets/lianjiang-350122.json'

const props = defineProps({
  /** 热力图网格：[{lng, lat, count, density, main_class}] */
  heatmap: { type: Array, default: () => [] },
  /** 设备：[{device_id, name, lng, lat, status, device_type}] */
  devices: { type: Array, default: () => [] },
  /** 机器人：[{robot_id, name, lng, lat, status, battery}] */
  robots: { type: Array, default: () => [] },
  /** 近期事件（用于打点） */
  events: { type: Array, default: () => [] },
  center: { type: Object, default: () => ({ lng: 119.86, lat: 26.35 }) },
  zoom: { type: Number, default: 11 },
})

const mapEl = ref(null)
const loadError = ref('')
const mapMode = ref('loading')
const offlineReason = ref('')
const selectedMarker = ref(null)
const localZoom = ref(1)
const localPan = reactive({ x: 0, y: 0 })
const dragging = ref(false)
let dragState = null

const layers = reactive([
  { key: 'heat', label: '热力分布', on: true },
  { key: 'cameras', label: '摄像头', on: true },
  { key: 'robots', label: '机器人', on: true },
  { key: 'events', label: '事件点', on: true },
])

const legend = CLASS_ORDER.map((k) => ({
  key: k,
  label: classLabel(k),
  color: classColor(k),
}))

const MAP_WIDTH = 1000
const MAP_HEIGHT = 700
const MAP_PADDING = 44

function collectCoordinates(geometry, result = []) {
  if (!geometry) return result
  if (geometry.type === 'Polygon') {
    geometry.coordinates.flat().forEach((coordinate) => result.push(coordinate))
  } else if (geometry.type === 'MultiPolygon') {
    geometry.coordinates.flat(2).forEach((coordinate) => result.push(coordinate))
  }
  return result
}

const geoCoordinates = lianjiangGeo.features.flatMap((feature) =>
  collectCoordinates(feature.geometry),
)
const GEO_BOUNDS = {
  minLng: Math.min(...geoCoordinates.map(([lng]) => lng)),
  maxLng: Math.max(...geoCoordinates.map(([lng]) => lng)),
  minLat: Math.min(...geoCoordinates.map(([, lat]) => lat)),
  maxLat: Math.max(...geoCoordinates.map(([, lat]) => lat)),
}

function projectLngLat(lng, lat) {
  const width = MAP_WIDTH - MAP_PADDING * 2
  const height = MAP_HEIGHT - MAP_PADDING * 2
  return {
    x: MAP_PADDING + ((lng - GEO_BOUNDS.minLng) / (GEO_BOUNDS.maxLng - GEO_BOUNDS.minLng)) * width,
    y: MAP_PADDING + ((GEO_BOUNDS.maxLat - lat) / (GEO_BOUNDS.maxLat - GEO_BOUNDS.minLat)) * height,
  }
}

function ringToPath(ring) {
  return `${ring
    .map(([lng, lat], index) => {
      const point = projectLngLat(lng, lat)
      return `${index ? 'L' : 'M'}${point.x.toFixed(2)} ${point.y.toFixed(2)}`
    })
    .join(' ')} Z`
}

function geometryToPath(geometry) {
  if (!geometry) return ''
  if (geometry.type === 'Polygon') {
    return geometry.coordinates.map(ringToPath).join(' ')
  }
  if (geometry.type === 'MultiPolygon') {
    return geometry.coordinates.flatMap((polygon) => polygon.map(ringToPath)).join(' ')
  }
  return ''
}

const lianjiangOutline = lianjiangGeo.features
  .map((feature) => geometryToPath(feature.geometry))
  .join(' ')

const maxHeatDensity = computed(() =>
  Math.max(...(props.heatmap || []).map((cell) => Number(cell.density) || 0), 1e-9),
)

const localHeat = computed(() =>
  (props.heatmap || []).map((cell, index) => {
    const ratio = Math.min(1, (Number(cell.density) || 0) / maxHeatDensity.value)
    return {
      key: `${cell.lng}-${cell.lat}-${index}`,
      ...projectLngLat(Number(cell.lng), Number(cell.lat)),
      radius: 10 + ratio * 28,
      color: classColor('foam'),
      opacity: 0.12 + ratio * 0.46,
    }
  }),
)

const localCameras = computed(() =>
  (props.devices || [])
    .filter((device) => device.device_type !== 'robot')
    .map((device) => {
      const online = device.status === 'online'
      return {
        id: device.device_id,
        ...projectLngLat(Number(device.lng), Number(device.lat)),
        color: online ? '#18a999' : '#7a8798',
        title: device.name || device.device_id,
        rows: [
          { label: '类型', value: '摄像头' },
          { label: '编号', value: device.device_id },
          { label: '状态', value: online ? '在线' : '离线' },
        ],
      }
    }),
)

const localRobots = computed(() =>
  (props.robots || []).map((robot) => {
    const busy = ['navigating', 'collecting', 'assigned'].includes(robot.status)
    const online = robot.status === 'online' || busy
    return {
      id: robot.robot_id,
      ...projectLngLat(Number(robot.lng), Number(robot.lat)),
      color: busy ? '#18a999' : online ? '#3f8ee8' : '#7a8798',
      title: robot.name || robot.robot_id,
      rows: [
        { label: '类型', value: '治理机器人' },
        { label: '编号', value: robot.robot_id },
        { label: '状态', value: robot.status || '未知' },
        { label: '电量', value: robot.battery == null ? '未知' : `${robot.battery}%` },
      ],
    }
  }),
)

const localEvents = computed(() =>
  (props.events || []).map((event, index) => ({
    id: event.event_id || `event-${index}`,
    ...projectLngLat(Number(event.lng), Number(event.lat)),
    color: classColor(event.main_class),
    title: `${classLabel(event.main_class)} ${event.det_count || 1} 个`,
    rows: [
      { label: '设备', value: event.device_id || '未关联' },
      { label: '数量', value: event.det_count || 1 },
      {
        label: '置信度',
        value: event.max_confidence
          ? `${(Number(event.max_confidence) * 100).toFixed(0)}%`
          : '未知',
      },
    ],
  })),
)

const offlineTransform = computed(() => {
  const centerX = MAP_WIDTH / 2
  const centerY = MAP_HEIGHT / 2
  return [
    `translate(${localPan.x} ${localPan.y})`,
    `translate(${centerX} ${centerY})`,
    `scale(${localZoom.value})`,
    `translate(${-centerX} ${-centerY})`,
  ].join(' ')
})

function layerEnabled(key) {
  return layers.find((layer) => layer.key === key)?.on !== false
}

function cameraPinPath(marker) {
  const { x, y } = marker
  return `M${x} ${y + 1.5}l-3.4-5.2a4.2 4.2 0 1 1 6.8 0L${x} ${y + 1.5}Z`
}

function boatPath(marker) {
  const { x, y } = marker
  return `M${x - 8} ${y + 2.5}h16l-3.2 4.8H${x - 4.8}L${x - 8} ${y + 2.5}ZM${x - 5.2} ${y + 1}h10.4l-2-6H${x - 3.2}L${x - 5.2} ${y + 1}Z`
}

function selectOfflineMarker(marker) {
  selectedMarker.value = selectedMarker.value?.id === marker.id ? null : marker
}

function clampLocalZoom(value) {
  return Math.min(2.8, Math.max(0.8, value))
}

function changeOfflineZoom(delta) {
  localZoom.value = clampLocalZoom(localZoom.value + delta)
  selectedMarker.value = null
}

function resetOfflineView() {
  localZoom.value = 1
  localPan.x = 0
  localPan.y = 0
  selectedMarker.value = null
}

function startOfflineDrag(event) {
  if (event.button !== 0) return
  if (event.target.closest?.('.offline-map__marker')) return
  const target = event.currentTarget
  target.setPointerCapture?.(event.pointerId)
  dragState = {
    pointerId: event.pointerId,
    clientX: event.clientX,
    clientY: event.clientY,
    panX: localPan.x,
    panY: localPan.y,
    rect: target.getBoundingClientRect(),
  }
  dragging.value = true
}

function moveOfflineDrag(event) {
  if (!dragState || dragState.pointerId !== event.pointerId) return
  const dx = ((event.clientX - dragState.clientX) / dragState.rect.width) * MAP_WIDTH
  const dy = ((event.clientY - dragState.clientY) / dragState.rect.height) * MAP_HEIGHT
  localPan.x = dragState.panX + dx
  localPan.y = dragState.panY + dy
}

function endOfflineDrag(event) {
  if (!dragState || (event?.pointerId != null && dragState.pointerId !== event.pointerId)) return
  dragState = null
  dragging.value = false
}

let map = null
let heatLayer = null
let cameraLayer = null
let robotLayer = null
let eventLayer = null

const SDK_URL = 'https://map.qq.com/api/gljs?v=1.exp'
const WB_PROXY = 'http://127.0.0.1:__WB_HTTP_PORT__/_TMapService/_wbt/__WB_TMAP_SECRET__'
const TMAP_PROXY_URL = import.meta.env.VITE_TMAP_PROXY_URL || WB_PROXY

function hasProxyConfig() {
  return /^https?:\/\//.test(TMAP_PROXY_URL) && !TMAP_PROXY_URL.includes('__WB_')
}

// ----------------------------------------------------------------------
// SDK 加载
// ----------------------------------------------------------------------
function loadSdk() {
  return new Promise((resolve, reject) => {
    if (window.TMap) {
      resolve()
      return
    }

    // key 代理配置 —— 必须早于 SDK 脚本
    window._TMapSecurityConfig = { serviceHost: TMAP_PROXY_URL }

    const script = document.createElement('script')
    let settled = false
    const finish = (callback, value) => {
      if (settled) return
      settled = true
      clearTimeout(timeout)
      callback(value)
    }
    const timeout = window.setTimeout(() => {
      script.remove()
      finish(reject, new Error('腾讯地图 SDK 加载超时'))
    }, 8000)

    script.src = SDK_URL
    script.async = true
    script.onload = () =>
      window.TMap
        ? finish(resolve)
        : finish(reject, new Error('SDK 加载后未挂载 TMap'))
    script.onerror = () => finish(reject, new Error('无法从 CDN 加载腾讯地图 SDK'))
    document.head.appendChild(script)
  })
}

function initializeOffline(reason) {
  loadError.value = ''
  offlineReason.value = reason
  mapMode.value = 'offline'
}

// ----------------------------------------------------------------------
// 图标（内联 SVG，不引用官方 demo 图片路径）
// ----------------------------------------------------------------------
function svgIcon(color, shape = 'pin') {
  const svg =
    shape === 'boat'
      ? `<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
           <circle cx="15" cy="15" r="12" fill="${color}" opacity="0.22"/>
           <circle cx="15" cy="15" r="6" fill="${color}" stroke="#070d14" stroke-width="1.5"/>
         </svg>`
      : shape === 'dot'
        ? `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
             <circle cx="8" cy="8" r="4" fill="${color}" stroke="#070d14" stroke-width="1.4"/>
           </svg>`
        : `<svg xmlns="http://www.w3.org/2000/svg" width="26" height="30" viewBox="0 0 26 30">
             <path d="M13 1C7 1 2.5 5.6 2.5 11.4c0 7.4 10.5 17.6 10.5 17.6s10.5-10.2 10.5-17.6C23.5 5.6 19 1 13 1z"
                   fill="${color}" stroke="#070d14" stroke-width="1.4"/>
             <circle cx="13" cy="11" r="3.6" fill="#070d14" opacity="0.65"/>
           </svg>`
  return `data:image/svg+xml,${encodeURIComponent(svg)}`
}

// ----------------------------------------------------------------------
// 图层构建
// ----------------------------------------------------------------------
function buildHeatLayer() {
  if (heatLayer) {
    heatLayer.setMap(null)
    heatLayer = null
  }
  if (!layers.find((l) => l.key === 'heat')?.on) return
  if (!props.heatmap?.length) return

  // 网格中心点 + 按事件数决定半径与透明度。
  // ★ 用密度而非总数决定颜色深浅 —— 网格大小不同时总数没有可比性。
  const maxDensity = Math.max(...props.heatmap.map((c) => c.density || 0), 1e-9)

  const geometries = props.heatmap.map((cell, i) => {
    const ratio = Math.min(1, (cell.density || 0) / maxDensity)
    return {
      id: `heat-${i}`,
      styleId: `heat-${Math.round(ratio * 5)}`,
      center: new window.TMap.LatLng(cell.lat, cell.lng),
    }
  })

  const styles = {}
  for (let i = 0; i <= 5; i++) {
    const ratio = i / 5
    styles[`heat-${i}`] = new window.TMap.CircleStyle({
      color: classColor('foam'),
      showBorder: false,
      // 半径按网格边长的一半缩放（500m 网格 → 半径约 250m 对应像素）
      radius: 14 + ratio * 26,
      opacity: 0.14 + ratio * 0.46,
    })
  }

  heatLayer = new window.TMap.MultiCircle({
    map,
    styles,
    geometries,
  })
}

function buildCameraLayer() {
  if (cameraLayer) {
    cameraLayer.setMap(null)
    cameraLayer = null
  }
  if (!layers.find((l) => l.key === 'cameras')?.on) return

  const cams = (props.devices || []).filter((d) => d.device_type !== 'robot')
  if (!cams.length) return

  cameraLayer = new window.TMap.MultiMarker({
    map,
    styles: {
      online: new window.TMap.MarkerStyle({
        width: 22,
        height: 26,
        anchor: { x: 11, y: 26 },
        src: svgIcon('#18e0c8'),
      }),
      offline: new window.TMap.MarkerStyle({
        width: 22,
        height: 26,
        anchor: { x: 11, y: 26 },
        src: svgIcon('#5a6678'),
      }),
    },
    geometries: cams.map((d) => ({
      id: d.device_id,
      styleId: d.status === 'online' ? 'online' : 'offline',
      position: new window.TMap.LatLng(d.lat, d.lng),
      properties: {
        title: d.name,
        content: `<div style="font-size:12px;line-height:1.7">
          <b>${d.name}</b><br/>
          编号：${d.device_id}<br/>
          状态：${d.status === 'online' ? '在线' : '离线'}
        </div>`,
      },
    })),
  })

  cameraLayer.on('click', (evt) => {
    const p = evt.geometry?.properties
    if (p) showInfo(p.title, p.content)
  })
}

function buildRobotLayer() {
  if (robotLayer) {
    robotLayer.setMap(null)
    robotLayer = null
  }
  if (!layers.find((l) => l.key === 'robots')?.on) return
  if (!props.robots?.length) return

  robotLayer = new window.TMap.MultiMarker({
    map,
    styles: {
      idle: new window.TMap.MarkerStyle({
        width: 28,
        height: 28,
        anchor: { x: 14, y: 14 },
        src: svgIcon('#4a9eff', 'boat'),
      }),
      busy: new window.TMap.MarkerStyle({
        width: 28,
        height: 28,
        anchor: { x: 14, y: 14 },
        src: svgIcon('#18e0c8', 'boat'),
      }),
      offline: new window.TMap.MarkerStyle({
        width: 28,
        height: 28,
        anchor: { x: 14, y: 14 },
        src: svgIcon('#5a6678', 'boat'),
      }),
    },
    geometries: (props.robots || []).map((r) => {
      const busy = ['navigating', 'collecting', 'assigned'].includes(r.status)
      const styleId =
        r.status === 'online' || busy ? (busy ? 'busy' : 'idle') : 'offline'
      return {
        id: r.robot_id,
        styleId,
        position: new window.TMap.LatLng(r.lat, r.lng),
        properties: {
          title: r.name || r.robot_id,
          content: `<div style="font-size:12px;line-height:1.7">
            <b>${r.name || r.robot_id}</b><br/>
            编号：${r.robot_id}<br/>
            状态：${r.status}<br/>
            电量：${r.battery ?? '—'}%
          </div>`,
        },
      }
    }),
  })

  robotLayer.on('click', (evt) => {
    const p = evt.geometry?.properties
    if (p) showInfo(p.title, p.content)
  })
}

function buildEventLayer() {
  if (eventLayer) {
    eventLayer.setMap(null)
    eventLayer = null
  }
  if (!layers.find((l) => l.key === 'events')?.on) return

  const events = props.events || []
  if (!events.length) return

  const styles = {}
  for (const cls of CLASS_ORDER) {
    styles[cls] = new window.TMap.MarkerStyle({
      width: 16,
      height: 16,
      anchor: { x: 8, y: 8 },
      src: svgIcon(classColor(cls), 'dot'),
    })
  }

  eventLayer = new window.TMap.MultiMarker({
    map,
    styles,
    geometries: events.map((e, i) => ({
      id: e.event_id || `evt-${i}`,
      styleId: CLASS_ORDER.includes(e.main_class) ? e.main_class : 'other',
      position: new window.TMap.LatLng(e.lat, e.lng),
      properties: {
        title: `${classLabel(e.main_class)} ${e.det_count || 1} 个`,
        content: `<div style="font-size:12px;line-height:1.7">
          <b>${classLabel(e.main_class)}</b><br/>
          设备：${e.device_id || '—'}<br/>
          数量：${e.det_count || 1}<br/>
          置信度：${e.max_confidence ? (Number(e.max_confidence) * 100).toFixed(0) + '%' : '—'}
        </div>`,
      },
    })),
  })

  eventLayer.on('click', (evt) => {
    const p = evt.geometry?.properties
    if (p) showInfo(p.title, p.content)
  })
}

let infoWindow = null
function showInfo(title, content) {
  if (!infoWindow) {
    infoWindow = new window.TMap.InfoWindow({
      map,
      offset: { x: 0, y: -30 },
    })
  }
  infoWindow.setContent(content)
  infoWindow.setPosition(null)
  // 简化处理：直接用内容替换，不强制定位（避免与 marker 位置耦合）
  infoWindow.open()
}

function refresh() {
  if (mapMode.value !== 'tencent' || !map) return
  buildHeatLayer()
  buildCameraLayer()
  buildRobotLayer()
  buildEventLayer()
}

// ----------------------------------------------------------------------
// 生命周期
// ----------------------------------------------------------------------
onMounted(async () => {
  if (!hasProxyConfig()) {
    initializeOffline('未配置腾讯地图密钥代理')
    return
  }

  try {
    await loadSdk()

    map = new window.TMap.Map(mapEl.value, {
      zoom: props.zoom,
      center: new window.TMap.LatLng(props.center.lat, props.center.lng),
      // ★ 不传 mapStyleId —— 自定义样式需在控制台单独开通，否则底图变灰
      baseMap: { type: 'vector' },
    })

    mapMode.value = 'tencent'
    refresh()
  } catch (err) {
    initializeOffline(err.message || String(err))
  }
})

onUnmounted(() => {
  endOfflineDrag()
  for (const layer of [heatLayer, cameraLayer, robotLayer, eventLayer]) {
    try {
      layer?.setMap(null)
    } catch {
      /* 忽略 */
    }
  }
  map = null
})

watch(
  () => [props.heatmap, props.devices, props.robots, props.events],
  refresh,
  { deep: false },
)
</script>

<style scoped>
.map-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.map-panel__body {
  position: relative;
  flex: 1;
  min-height: 320px;
  overflow: hidden;
  border-radius: 0 0 var(--radius-lg) var(--radius-lg);
}

#seasight-map {
  width: 100%;
  height: 100%;
  min-height: 320px;
  background: var(--bg-panel-2);
}

.offline-map {
  position: absolute;
  inset: 0;
  z-index: 1;
  width: 100%;
  height: 100%;
  background: #dceaf5;
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.offline-map--dragging {
  cursor: grabbing;
}

.offline-map__land-shadow {
  fill: #f7faf8;
  stroke: none;
  filter: url(#offline-shadow);
}

.offline-map__land {
  fill: url(#offline-land);
}

.offline-map__coast {
  fill: none;
  stroke: #b7c8d3;
  stroke-width: 1.15;
  stroke-linejoin: round;
  vector-effect: non-scaling-stroke;
}

.offline-map__terrain {
  fill: none;
  stroke: #d6ddd8;
  stroke-width: 1.1;
  stroke-opacity: 0.62;
  vector-effect: non-scaling-stroke;
}

.offline-map__roads {
  fill: none;
  stroke-linecap: round;
  stroke-linejoin: round;
  vector-effect: non-scaling-stroke;
}

.offline-map__road-casing path {
  stroke: #d5d9d8;
  stroke-width: 6.8;
  stroke-opacity: 0.92;
}

.offline-map__road-fill path {
  stroke: #ffffff;
  stroke-width: 4.2;
}

.offline-map__road-minor path {
  stroke: #ffffff;
  stroke-width: 2.25;
  stroke-opacity: 0.94;
}

.offline-map__labels {
  pointer-events: none;
}

.offline-map__place circle {
  fill: #69737a;
  stroke: rgba(255, 255, 255, 0.96);
  stroke-width: 1.7;
}

.offline-map__place text {
  fill: #68737a;
  stroke: rgba(255, 255, 255, 0.94);
  stroke-width: 2.8;
  paint-order: stroke;
  font-size: 10.5px;
  font-weight: 520;
  letter-spacing: 0.35px;
}

.offline-map__place--major circle {
  fill: #49535a;
}

.offline-map__place--major text {
  fill: #465159;
  font-size: 13.5px;
  font-weight: 680;
  letter-spacing: 0.5px;
}

.offline-map__water-label,
.offline-map__ocean-label {
  fill: #6d9bbb;
  stroke: rgba(229, 240, 248, 0.7);
  stroke-width: 2.4;
  paint-order: stroke;
}

.offline-map__water-label {
  font-size: 11px;
  font-weight: 520;
  letter-spacing: 2.4px;
}

.offline-map__ocean-label {
  fill: #83a8c1;
  font-size: 15px;
  font-weight: 520;
  letter-spacing: 8px;
  opacity: 0.72;
}

.offline-map__marker {
  cursor: pointer;
  outline: none;
}

.offline-map__marker:focus circle:last-of-type,
.offline-map__marker:hover circle:last-of-type {
  stroke: #ffffff;
  stroke-width: 2.4;
}

.offline-map__heat {
  pointer-events: none;
}

.map-controls {
  position: absolute;
  z-index: 6;
  top: 10px;
  left: 10px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.78);
  border-radius: 13px;
  background: rgba(255, 255, 255, 0.8);
  box-shadow:
    0 1px 2px rgba(24, 44, 58, 0.08),
    0 8px 24px rgba(24, 44, 58, 0.14);
  backdrop-filter: blur(18px) saturate(1.25);
  -webkit-backdrop-filter: blur(18px) saturate(1.25);
}

.map-controls button {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  padding: 0;
  border: 0;
  border-radius: 0;
  background: transparent;
  color: #3f4a51;
  box-shadow: none;
  font-size: 18px;
  font-weight: 450;
  line-height: 1;
  cursor: pointer;
}

.map-controls button + button {
  border-top: 1px solid rgba(60, 60, 67, 0.13);
}

.map-controls button:hover {
  background: rgba(255, 255, 255, 0.9);
  color: #007aff;
}

.map-controls button:active {
  background: rgba(0, 122, 255, 0.08);
}

.offline-badge {
  position: absolute;
  z-index: 4;
  bottom: 10px;
  left: 10px;
  display: flex;
  flex-direction: column;
  gap: 1px;
  padding: 7px 10px;
  border: 1px solid rgba(255, 255, 255, 0.76);
  border-radius: 11px;
  background: rgba(255, 255, 255, 0.79);
  color: #35434b;
  box-shadow:
    0 1px 2px rgba(37, 51, 61, 0.08),
    0 7px 22px rgba(37, 51, 61, 0.12);
  font-size: 11px;
  line-height: 1.35;
  pointer-events: none;
  backdrop-filter: blur(18px) saturate(1.25);
  -webkit-backdrop-filter: blur(18px) saturate(1.25);
}

.offline-badge small {
  color: #7c898f;
  font-size: 9px;
}

.offline-info {
  position: absolute;
  z-index: 8;
  top: 10px;
  left: 54px;
  display: flex;
  flex-direction: column;
  min-width: 190px;
  max-width: min(280px, calc(100% - 190px));
  gap: 4px;
  padding: 11px 34px 11px 12px;
  border: 1px solid var(--panel-border);
  border-radius: 12px;
  background: color-mix(in srgb, var(--bg-panel) 96%, transparent);
  box-shadow: 0 12px 34px rgba(16, 49, 65, 0.18);
  color: var(--text-sub);
  font-size: 11.5px;
  line-height: 1.35;
  backdrop-filter: blur(16px) saturate(1.2);
  -webkit-backdrop-filter: blur(16px) saturate(1.2);
}

.offline-info strong {
  padding-right: 2px;
  color: var(--text-main);
  font-size: 13px;
}

.offline-info > button {
  position: absolute;
  top: 5px;
  right: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--text-dim);
  font-size: 18px;
  cursor: pointer;
}

.offline-info > button:hover {
  background: var(--bg-hover);
  color: var(--text-main);
}

.map-loading {
  position: absolute;
  inset: 0;
  z-index: 7;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 9px;
  background: var(--bg-panel-2);
  color: var(--text-sub);
  font-size: 12px;
}

.map-loading__spinner {
  width: 15px;
  height: 15px;
  border: 2px solid var(--border);
  border-top-color: var(--c-primary);
  border-radius: 50%;
  animation: map-spin 0.8s linear infinite;
}

@keyframes map-spin {
  to { transform: rotate(360deg); }
}

.map-legend {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 10px;
  font-size: 12px;
  color: var(--text-sub);
  font-weight: 400;
}

.map-legend__item {
  display: flex;
  align-items: center;
  white-space: nowrap;
}

.map-tools {
  position: absolute;
  top: 10px;
  right: 10px;
  background: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(255, 255, 255, 0.78);
  border-radius: 13px;
  padding: 8px 10px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
  z-index: 5;
  box-shadow:
    0 1px 2px rgba(24, 44, 58, 0.07),
    0 8px 24px rgba(24, 44, 58, 0.13);
  backdrop-filter: blur(18px) saturate(1.25);
  -webkit-backdrop-filter: blur(18px) saturate(1.25);
}

.map-tools__item {
  display: flex;
  align-items: center;
  gap: 5px;
  color: #4f5c63;
  cursor: pointer;
  user-select: none;
}

.map-tools__item input {
  width: 16px;
  height: 16px;
  margin: 0;
  accent-color: #007aff;
  cursor: pointer;
}

.map-error {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background: var(--bg-panel-2);
  color: var(--text-sub);
  font-size: 13px;
}

.map-error__hint {
  font-size: 12px;
  color: var(--text-dim);
  max-width: min(90%, 520px);
  text-align: center;
  word-break: break-word;
}

@media (max-width: 760px) {
  .map-panel .panel-title {
    align-items: flex-start;
    flex-direction: column;
    gap: 8px;
  }

  .map-legend {
    width: 100%;
    justify-content: flex-start;
    flex-wrap: nowrap;
    gap: 12px;
    padding-bottom: 2px;
    overflow-x: auto;
    scrollbar-width: none;
  }

  .map-legend::-webkit-scrollbar {
    display: none;
  }

  .map-panel__body,
  #seasight-map {
    min-height: 280px;
  }

  .map-tools {
    top: 8px;
    right: 8px;
    display: grid;
    grid-template-columns: repeat(2, auto);
    gap: 7px 10px;
    padding: 8px;
    border-radius: 10px;
  }

  .offline-info {
    top: auto;
    right: 10px;
    bottom: 64px;
    left: 82px;
    min-width: 0;
    max-width: none;
  }
}

@media (max-width: 380px) {
  .map-panel__body,
  #seasight-map {
    min-height: 250px;
  }

  .map-tools {
    font-size: 11px;
  }

  .map-tools__item input {
    width: 15px;
    height: 15px;
  }
}
</style>
