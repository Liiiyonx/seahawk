<template>
  <svg
    class="logo-mark"
    viewBox="0 0 48 48"
    :width="size"
    :height="size"
    aria-hidden="true"
  >
    <defs>
      <linearGradient :id="backgroundId" x1="7" y1="4" x2="41" y2="44" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#0877e8" />
        <stop offset="1" stop-color="#00a6c8" />
      </linearGradient>
      <linearGradient :id="irisId" x1="18" y1="12" x2="30" y2="24" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#d8fbff" />
        <stop offset="1" stop-color="#5de5ff" />
      </linearGradient>
    </defs>

    <!-- 应用图标底座：保证 Logo 在顶栏、浏览器标签和移动端保持同一识别 -->
    <rect x="2" y="2" width="44" height="44" rx="13" :fill="`url(#${backgroundId})`" />
    <rect
      x="2.75"
      y="2.75"
      width="42.5"
      height="42.5"
      rx="12.25"
      fill="none"
      stroke="#ffffff"
      stroke-opacity="0.2"
      stroke-width="1.5"
    />

    <!-- 灵眸 -->
    <path
      d="M8 17.5C12.5 10.7 18.2 7.5 24 7.5s11.5 3.2 16 10c-4.5 6.8-10.2 10-16 10S12.5 24.3 8 17.5Z"
      fill="none"
      stroke="#ffffff"
      stroke-width="2.15"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <circle cx="24" cy="17.5" r="6.4" :fill="`url(#${irisId})`" />
    <circle cx="24" cy="17.5" r="2.75" fill="#06233e" />
    <circle cx="21.5" cy="14.9" r="1.35" fill="#ffffff" opacity="0.92" />

    <!-- 探海波浪 -->
    <path
      d="M10 31.2c2.4-2.1 4.8-2.1 7.2 0s4.8 2.1 7.2 0 4.8-2.1 7.2 0 4.8 2.1 7.2 0"
      fill="none"
      stroke="#ffffff"
      stroke-width="2.05"
      stroke-linecap="round"
    />
    <path
      d="M15 37c1.9-1.6 3.8-1.6 5.7 0s3.8 1.6 5.7 0 3.8-1.6 5.7 0"
      fill="none"
      stroke="#ffffff"
      stroke-opacity="0.58"
      stroke-width="1.6"
      stroke-linecap="round"
    />
  </svg>
</template>

<script setup>
import { useId } from 'vue'

defineProps({
  size: { type: Number, default: 30 },
})

const uid = useId().replace(/[^a-zA-Z0-9_-]/g, '')
const backgroundId = `seasight-logo-bg-${uid}`
const irisId = `seasight-logo-iris-${uid}`
</script>

<style scoped>
.logo-mark {
  display: block;
  flex: 0 0 auto;
  filter: drop-shadow(0 5px 12px rgba(0, 92, 190, 0.2));
}
</style>
